#' A fake data set on self-other agreement
#' 
#' The data set selfother is a self-generated fake data set which can, for example, be used to try out the inclusion of control variables in the RSA() function and to try out cubic RSA. The variables in the data set are meant to reflect the following constructs: 
#' 
#' \itemize{
#'   \item IQ_self Self-rated intelligence (on IQ scale)
#'   \item IQ_friend Friend-rated intelligence (on IQ scale)
#'   \item harmony Level of harmony in typical interactions between the target person and the friend
#'   \item VI_self Self-reported value importance
#'   \item VI_partner Partner-reported value importance
#'   \item distance Emotional distance felt toward the partner
#'   \item age Age of the target person
#'   \item int Typical number of interactions between the target person and the friend (who provided the intelligence rating) per week
#'   \item liking Target person's rating about how much he/she likes the friend
#' }
#' 
#' @docType data
#' @keywords datasets
#' @format A data frame with 800 rows and 9 variables
#' @name selfother
NULL